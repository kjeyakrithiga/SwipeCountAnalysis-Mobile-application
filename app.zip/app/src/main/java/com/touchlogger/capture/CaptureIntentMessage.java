package com.touchlogger.capture;

public enum CaptureIntentMessage {
    START,
    STOP
}
